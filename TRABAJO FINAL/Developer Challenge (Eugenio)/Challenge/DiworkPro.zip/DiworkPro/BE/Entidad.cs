﻿using Abstract;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Abstract;

namespace BE
{
    public class Entidad : IEntidad
    {
        public int Id { get; set; }
    }
}
