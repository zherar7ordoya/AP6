﻿using System.Collections.Generic;

namespace GameStore.Core.ViewModels.Games
{
    public class GameGroupVm 
    {
        public int Id { get; set; }
        public string Title { get; set; }
        public int GameCount { get; set; }

    }
}
