# GameStore
Winform application with clean architecture for csharp class.

* .Net 5
* EF Core 5.0.10
* Clean architecture
  * Domain
  * Data
  * Core
  * IoC
  * Presentation (Winforms & Console App)
  
