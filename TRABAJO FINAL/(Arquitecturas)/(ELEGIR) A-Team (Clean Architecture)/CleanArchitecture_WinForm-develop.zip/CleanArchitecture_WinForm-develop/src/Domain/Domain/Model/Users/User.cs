﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Domain.Domain.Model.Users
{
    public class User
    {
        public UserId Id { get; }

        public string Name { get; set; }
    }
}
