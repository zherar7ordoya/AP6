﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Menpos.Application.Modules.Fiscal
{
    class FiscalExample
    {
    }
}
