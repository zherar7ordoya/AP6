﻿using System;

namespace Menpos.Infrastructure
{
    public class Class1
    {
    }
}
