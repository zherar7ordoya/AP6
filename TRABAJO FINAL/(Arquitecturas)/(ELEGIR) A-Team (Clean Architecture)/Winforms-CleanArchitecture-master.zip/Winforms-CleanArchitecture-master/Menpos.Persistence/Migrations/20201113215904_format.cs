﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace Menpos.Persistence.Migrations
{
    public partial class format : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {

        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {

        }
    }
}
