﻿using Entity.Concrate;
using System.Data;

namespace DataAccess.Concrete.AdoNet
{
    //public class MMSDataContext:DataContext
    //{
    //    public MMSDataContext(string connection) : base(connection)
    //    {
    //        //connection = @"Data Source=DESKTOP-2322UUL\SQLSERVER;User Id=sa;Password=12345";
    //    }
    //    public Table<Genre> Genres { get; set; }
    //}
}
