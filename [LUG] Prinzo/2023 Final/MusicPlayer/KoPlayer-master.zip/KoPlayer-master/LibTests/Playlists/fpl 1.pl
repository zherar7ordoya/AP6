FilterPlaylist
fpl 1
0
StringFilter
genre
noise
True
DateFilter
0
10
RatingFilter
4
True
True
