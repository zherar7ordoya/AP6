﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace KoPlayer.Lib.Filters
{
    public abstract class Filter
    {
        public void ApplyTo(List<Song> songs)
        {
            songs.RemoveAll(s => !Allowed(s));
        }

        public void Save(StreamWriter sw)
        {
            sw.WriteLine(GetType().Name);
            SaveData(sw);
        }

        protected abstract void SaveData(StreamWriter sw);
        public abstract bool Allowed(Song song);
    }
}
