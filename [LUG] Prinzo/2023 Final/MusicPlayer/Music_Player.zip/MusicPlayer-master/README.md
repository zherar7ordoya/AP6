# Music-Player

A simple Winforms app with basic functions for a music player with :
 - Play
 - Pause
 - Previous
 - Next
 
From the main menu strip there are menu, playlist and information tabs.  
Only files in audio format, as well as playlists, can be opened and added to playlist.

 <img src="https://image.ibb.co/csBx89/musicplayerplaylist.png">



## Playlist

An advanced function is adding and saving a song to a playlist using :
 - two arrays of FilePath and FileName
 - try catch block with binary stream StreamReader and one for cycle    
 iterating throught FileName for adding a song to listbox playlist
 
 
  <img src="https://image.ibb.co/iP5Qd9/carbon.png">	
 
		 
		 
 - try catch block with binary stream StreamWriter and one foreach cycle iterating throught the playlist items for saving
 
  <img src="https://image.ibb.co/bNaDWU/carbon_1.png">
	         

		     
 - one finally block for saving
