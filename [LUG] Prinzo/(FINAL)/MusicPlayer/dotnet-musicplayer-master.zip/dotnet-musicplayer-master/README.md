# dotnet-musicplayer
Music Player with spectrum visualizer written in C# using WinForms, NAudio, TagLib and SDL2.

To run this application properly, you need to move the SDL runtime library from SDL_runtime/ folder to application's bin/ folder.