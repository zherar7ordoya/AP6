# SimpleMusicPlayer
Simple music player made with WinForms
