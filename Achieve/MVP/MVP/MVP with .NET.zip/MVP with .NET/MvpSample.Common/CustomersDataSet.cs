﻿namespace MvpSample.Common {


    partial class CustomersDataSet
    {
        partial class CusomersTableDataTable
        {
        }
    }
}
