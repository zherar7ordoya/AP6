﻿namespace MvpSample.WebForms {


    partial class CustomersDataSet
    {
        partial class CusomersTableDataTable
        {
        }
    }
}
